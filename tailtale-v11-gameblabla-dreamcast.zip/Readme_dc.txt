===============
Tail-Tale v1.1
===============
Game by fumi2kick, rerofumi and pyonkey-matsuo 
Sega Dreamcast port by gameblabla

It's a puzzle game, kind of like Tetris Attack for SNES.

To hold a block, press A.
While holding a block, you can move it.
When you're happy, release it.
Align 4 or more blocks of the same color to clear them !

You can burn the cdi image with ImgBurn and the cdi plugin.
Burn at 10x (or 12x if you can)

Changelog:
V1.1 : Recompiled against newer SDL version. This should speed it up a bit.
It was already fullspeed before but at least this should reduce the power consumption.
